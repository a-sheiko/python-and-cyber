# python-fundamentals
A collection of Google Colab notebooks for use with our Python Fundamentals course
